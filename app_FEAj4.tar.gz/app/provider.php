<?php
return [
    'think\exception\Handle'       => \app\common\exception\Http::class,
];