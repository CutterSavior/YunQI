<?php
// 这是系统自动生成的event定义文件
return [
    'listen'  =>    [
        'write_log'    =>    [app\common\listener\WriteLog::class]
    ],
];
