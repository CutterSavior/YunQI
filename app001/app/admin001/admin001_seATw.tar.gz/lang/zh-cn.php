<?php
use app\admin\controller\Ajax;
use app\admin\controller\Index;
return [
    //全局语言包
    'default'=>[

    ],
    //控制器语言包
    'controller'=>[
        Index::class=>[

        ],
        Ajax::class=>[

        ]
    ]
];